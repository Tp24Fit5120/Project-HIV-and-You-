using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Open : MonoBehaviour
{
    [SerializeField]
    private Text openText;
    private bool openAllowed;
    public GameObject openCondom;

    // Start is called before the first frame update
    private void Start()
    {
        openText.gameObject.SetActive(false);
    }

    // Update is called once per frame
    private void Update()
    {
        if(openAllowed && Input.GetKeyDown(KeyCode.E))
        Opened();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            openText.gameObject.SetActive(true);
            openAllowed = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            openText.gameObject.SetActive(false);
            openAllowed = false;
        }
    }

    private void Opened()
    {
        Destroy(gameObject);
        openCondom.SetActive(true);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour
{
    public GameObject condom, opencondom, wearcondom, fitcondom, happy, trash, condomblack, opencondomblack, wearcondomblack, fitcondomblack, happyblack, trashblack;
    
    Vector2 condomInitialPos, opencondomInitialPos, wearcondomInitialPos, fitcondomInitialPos, happyInitialPos, trashInitialPos;

    public AudioSource source;
    public AudioClip correct;
    public AudioClip incorrect;

    bool condomCorrect, opencondomCorrect, wearcondomCorrect, fitcondomCorrect, happyCorrect, trashCorrect = false;

    public GameObject complete;
    
    public void Complete()
    {
        complete.SetActive(true);
    }

    void Start()
    {
        condomInitialPos = condom.transform.position;
        opencondomInitialPos = opencondom.transform.position;
        wearcondomInitialPos = wearcondom.transform.position;
        fitcondomInitialPos = fitcondom.transform.position;
        happyInitialPos = happy.transform.position;
        trashInitialPos = trash.transform.position;
    }

    public void DragCondom()
    {
        condom.transform.position = Input.mousePosition;
    }

    public void DragOpenCondom()
    {
        opencondom.transform.position = Input.mousePosition;
    }

    public void DragWearCondom()
    {
        wearcondom.transform.position = Input.mousePosition;
    }    

    public void DragFitCondom()
    {
        fitcondom.transform.position = Input.mousePosition;
    }    

    public void DragHappy()
    {
        happy.transform.position = Input.mousePosition;
    }    

    public void DragTrash()
    {
        trash.transform.position = Input.mousePosition;
    }  

    public void DropCondom()
    {
        float Distance = Vector3.Distance(condom.transform.position, condomblack.transform.position);
        if(Distance<50)
        {
            condom.transform.position=condomblack.transform.position;
            source.clip=correct;
            source.Play();
            condomCorrect=true;
        }
        else
        {
            condom.transform.position=condomInitialPos;
            source.clip=incorrect;
            source.Play();
        }
    }

        public void DropOpenCondom()
    {
        float Distance = Vector3.Distance(opencondom.transform.position, opencondomblack.transform.position);
        if(Distance<50)
        {
            opencondom.transform.position=opencondomblack.transform.position;
            source.clip=correct;
            source.Play();
            opencondomCorrect=true;
        }
        else
        {
            opencondom.transform.position=opencondomInitialPos;
            source.clip= incorrect;
            source.Play();
        }
    }

        public void DropWearCondom()
    {
        float Distance = Vector3.Distance(wearcondom.transform.position, wearcondomblack.transform.position);
        if(Distance<50)
        {
            wearcondom.transform.position=wearcondomblack.transform.position;
            source.clip=correct;
            source.Play();
            wearcondomCorrect=true;
        }
        else
        {
            wearcondom.transform.position=wearcondomInitialPos;
            source.clip=incorrect;
            source.Play();
        }
    }

        public void DropFitCondom()
    {
        float Distance = Vector3.Distance(fitcondom.transform.position, fitcondomblack.transform.position);
        if(Distance<50)
        {
            fitcondom.transform.position=fitcondomblack.transform.position;
            source.clip=correct;
            source.Play();
            fitcondomCorrect=true;
        }
        else
        {
            fitcondom.transform.position=fitcondomInitialPos;
            source.clip=incorrect;
            source.Play();
        }
    }

        public void DropHappy()
    {
        float Distance = Vector3.Distance(happy.transform.position, happyblack.transform.position);
        if(Distance<50)
        {
            happy.transform.position=happyblack.transform.position;
            source.clip=correct;
            source.Play();
            happyCorrect=true;
        }
        else
        {
            happy.transform.position=happyInitialPos;
            source.clip=incorrect;
            source.Play();
        }
    }

        public void DropTrash()
    {
        float Distance = Vector3.Distance(trash.transform.position, trashblack.transform.position);
        if(Distance<50)
        {
            trash.transform.position=trashblack.transform.position;
            source.clip=correct;
            source.Play();
            trashCorrect=true;
        }
        else
        {
            trash.transform.position=trashInitialPos;
            source.clip=incorrect;
            source.Play();
        }
    }

    void Update()
    {
        if(condomCorrect && opencondomCorrect && wearcondomCorrect && fitcondomCorrect && happyCorrect && trashCorrect)
        {
            complete.SetActive(true);
        }
    }
}

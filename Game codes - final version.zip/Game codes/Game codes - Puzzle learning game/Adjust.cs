using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Adjust : MonoBehaviour
{

[SerializeField]
private Text adjustText;
private bool adjustAllowed;

public GameObject adjustCondom;

// Start is called before the first frame update
private void Start()
{
    adjustText.gameObject.SetActive(false);
}

// Update is called once per frame
private void Update()
{
    if(adjustAllowed && Input.GetKeyDown(KeyCode.E))
    Adjusted();
}

private void OnTriggerEnter2D(Collider2D other)
{
    if(other.tag == "dick")
    {
        adjustText.gameObject.SetActive(true);
        adjustAllowed = true;
    }
}

private void OnTriggerExit2D(Collider2D other)
{
    if(other.tag == "dick")
    {
        adjustText.gameObject.SetActive(false);
        adjustAllowed = false;
    }
}

private void Adjusted()
{
    Destroy(gameObject);
    adjustCondom.SetActive(true);
}
}

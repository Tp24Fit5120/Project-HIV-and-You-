using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Remove : MonoBehaviour
{
    [SerializeField]
    private Text removeText;
    private bool removeAllowed;
    
    public GameObject dick;
    public GameObject pants;

    // Start is called before the first frame update
    void Start()
    {
        removeText.gameObject.SetActive(false);
    }

    // Update is called once per frame
    private void Update()
    {
        if(removeAllowed && Input.GetKeyDown(KeyCode.E))
        Removed();
    }

    //remove pants
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Finish")
        {
            removeText.gameObject.SetActive(true);
            removeAllowed = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if(other.tag == "Finish")
        {
            removeText.gameObject.SetActive(false);
            removeAllowed = false;
        }
    }

        private void Removed()
    {
        dick.SetActive(true);
        pants.SetActive(false);
    }
}

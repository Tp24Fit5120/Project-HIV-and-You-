using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Roll : MonoBehaviour
{
    [SerializeField]
    private Text rollText;
    private bool rollAllowed;
    public GameObject rollIntoDick;
    public GameObject adjustCondom;
    public GameObject completed;

    // Start is called before the first frame update
    void Start()
    {
        rollText.gameObject.SetActive(false);
    }

    // Update is called once per frame
    private void Update()
    {
        if(rollAllowed && Input.GetKeyDown(KeyCode.E))
        Rolled();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            rollText.gameObject.SetActive(true);
            rollAllowed = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            rollText.gameObject.SetActive(false);
            rollAllowed = false;
        }
    }

    private void Rolled()
    {
        rollIntoDick.SetActive(true);
        adjustCondom.SetActive(false);
        completed.SetActive(true);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Erect : MonoBehaviour
{
    [SerializeField]
    private Text erectText;
    private bool erectAllowed;
    public GameObject erectedDick;
    public GameObject sleepDick;
    public GameObject adjustCondom;


    // Start is called before the first frame update
    private void Start()
    {
        erectText.gameObject.SetActive(false);
    }

    // Update is called once per frame
    private void Update()
    {
        if(erectAllowed && Input.GetKeyDown(KeyCode.E))
        Erected();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            erectText.gameObject.SetActive(true);
            erectAllowed = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            erectText.gameObject.SetActive(false);
            erectAllowed = false;
        }
    }

    private void Erected()
    {
        Destroy(gameObject);
        erectedDick.SetActive(true);
        sleepDick.SetActive(false);
        adjustCondom.SetActive(true);
    }
}

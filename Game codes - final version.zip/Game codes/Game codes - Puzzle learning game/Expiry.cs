using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Expiry : MonoBehaviour
{
    [SerializeField]
    private Text expiryText;
    private bool checkAllowed;
    
    public GameObject checkCondom;

    // Start is called before the first frame update
    private void Start()
    {
        expiryText.gameObject.SetActive(false);
    }

    // Update is called once per frame
    private void Update()
    {
        if(checkAllowed && Input.GetKeyDown(KeyCode.E))
        Checked();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            expiryText.gameObject.SetActive(true);
            checkAllowed = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if(other.tag == "dick")
        {
            expiryText.gameObject.SetActive(false);
            checkAllowed = false;
        }
    }

    private void Checked()
    {
        Destroy(gameObject);
        checkCondom.SetActive(true);
    }

}
